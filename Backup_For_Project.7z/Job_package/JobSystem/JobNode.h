#pragma once
#include <vector>
#include <atomic>
#include <mutex>
#include <condition_variable>
#include "ConcurrentQueue.h"
#include "../Common/Pool.h"
#include <DirectXMath.h>
#include "../Common/TypeWiper.h"
#include "../Common/MetaLib.h"
class JobHandle;
class JobThreadRunnable;
class JobBucket;
class VectorPool;
class JobSystem;
typedef unsigned int uint;
class JobNode
{
	friend class JobBucket;
	friend class JobSystem;
	friend class JobHandle;
	friend class JobThreadRunnable;
private:
	StackObject<std::vector<JobNode*>> dependingEvent;
	void* ptr;
	void(*destructorFunc)(void*) = nullptr;
	void(*executeFunc)(void*);
	std::mutex* threadMtx;
	std::atomic<unsigned int> targetDepending;
	bool dependedEventInitialized = false;
	void Create(const FunctorData& funcData, void* funcPtr, JobSystem* sys, JobHandle* dependedJobs, size_t size, uint dependCount);
	JobNode* Execute(ConcurrentQueue<JobNode*>& taskList, std::condition_variable& cv);
public:
	void Reset();
	void Dispose();
	~JobNode();
};