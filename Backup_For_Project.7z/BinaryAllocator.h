#pragma once
#include <stdint.h>
#include <vector>
#include <unordered_map>
typedef uint32_t uint;
typedef uint64_t uint64;


class BinaryAllocator
{
public:
	struct BinaryTreeNode
	{
		uint64 size;
		uint64 offset;
		uint layer;
		bool isRight() const noexcept
		{
			return (offset / size) % 2;
		}
		BinaryTreeNode() {}
		BinaryTreeNode(uint64 size, uint64 offset, uint layer)
		{
			this->size = size;
			this->layer = layer;
			this->offset = offset;
		}
		bool operator==(const BinaryTreeNode& node) const noexcept
		{
			return size == node.size && offset == node.offset && layer == node.layer;
		}

		bool operator!=(const BinaryTreeNode& node) const noexcept
		{
			return !operator==(node);
		}
	};

	struct AllocatedChunkHandle
	{
		friend class BinaryAllocator;
	private:
		BinaryTreeNode node;
	public:
		uint64 GetSize() const noexcept { return node.size; }
		uint64 GetOffset() const noexcept { return node.offset; }
	};
private:
	struct BinaryCoord
	{
		uint layer;
		uint index;
	};
	struct BinaryTreeNodeHash
	{
		size_t operator()(const BinaryTreeNode& node) const noexcept
		{
			return
				(std::hash<int64_t>::_Do_hash(node.size) << 8) ^
				(std::hash<uint64>::_Do_hash(node.offset) << 4) ^
				(std::hash<uint>::_Do_hash(node.layer));
		}
	};
	std::unordered_map<BinaryTreeNode, BinaryCoord, BinaryTreeNodeHash> singleNodeCacheDict;
	std::vector<std::vector<BinaryTreeNode>> usefulNodes;
	uint64_t rootChunkSize;
	void ReturnChunk(const BinaryTreeNode& node);
	void AddNode(const BinaryTreeNode& node);
	bool RemoveNode(const BinaryTreeNode& node);
public:
	size_t GetLayerCount() const { return usefulNodes.size(); }
	bool TryAllocate(uint targetLevel, AllocatedChunkHandle& result);
	void Return(const AllocatedChunkHandle& target);
	BinaryAllocator(
		uint32_t maximumLayer);
	~BinaryAllocator();
};
